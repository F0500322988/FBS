'use strict';
// Optional browser acceptance: node tests/browser/m174-broadcast.cjs (Playwright + Chromium).
const {chromium}=require('playwright');
const fs=require('node:fs');const path=require('node:path');const assert=require('node:assert/strict');
const publicRoot=path.resolve(__dirname,'../../public');
(async()=>{
 const browser=await chromium.launch({headless:true,...(process.env.FBS_BROWSER_EXECUTABLE?{executablePath:process.env.FBS_BROWSER_EXECUTABLE}:{}),args:['--no-sandbox']});
 try{
  const page=await browser.newPage({viewport:{width:1280,height:900}}),errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  let statusFail=false,framesFail=false,devices=[],frameMode='fresh',messages=[],messageFail=false,sends=[],broadcast={active:false},captured=[],startCalls=0,frameFail=false;
  const image='data:image/jpeg;base64,/9j/2Q==';
  await page.route('http://localhost:41999/**',async route=>{
   const url=new URL(route.request().url());let body,type='application/json',status=200;
   if(url.pathname==='/api/auth')body={required:false};
   else if(url.pathname==='/api/assist')body={status:'idle'};
   else if(url.pathname==='/api/lab-profiles')body={version:1,revision:0,profiles:[]};
   else if(url.pathname==='/api/lab-settings')body={version:1,revision:0,name:'معمل الاختبار',platform:'windows',groups:[]};
   else if(url.pathname==='/api/status'){status=statusFail?503:200;body={mode:'live',lab:{name:'معمل الاختبار'},students:devices};}
   else if(url.pathname==='/api/frames'){status=framesFail?503:200;body={frames:devices.map(d=>({id:d.id,jpeg:image,at:Date.now()-(frameMode==='stale'?6000:0)}))};}
   else if(url.pathname==='/api/messages'){
    if(route.request().method()==='POST'){
     const data=route.request().postDataJSON();sends.push(data);status=messageFail?409:202;
     if(!messageFail)messages.unshift({id:'browser-test',text:data.text,recipients:data.deviceIds.map(id=>({id,state:'queued'}))});body={id:'browser-test'};
    }else body={messages};
   }
   else if(url.pathname.startsWith('/api/broadcast')){
    const data=route.request().method()==='POST'?route.request().postDataJSON():null;
    if(url.pathname.endsWith('/start')){startCalls++;broadcast={active:true,id:'00000000-0000-0000-0000-000000000001',deviceIds:data.deviceIds,expiresAt:Date.now()+900000};status=201;}
    if(url.pathname.endsWith('/frame')){captured.push(data);status=frameFail?503:202;}
    if(url.pathname.endsWith('/stop'))broadcast={active:false};
    body=url.pathname.endsWith('/frame')?{accepted:!frameFail}:broadcast;
   }
   else if(url.pathname==='/api/enrollment/devices')body={devices:[]};
   else {const file=url.pathname==='/'?'index.html':url.pathname.slice(1);if(!/^[\w.-]+$/.test(file))throw Error('Unexpected route');body=fs.readFileSync(path.join(publicRoot,file));type=file.endsWith('.js')?'text/javascript':file.endsWith('.css')?'text/css':'text/html';}
   await route.fulfill({status,contentType:type,body:Buffer.isBuffer(body)?body:JSON.stringify(body)});
  });
  // HTML must be sent as raw bytes by the static mock.
  await page.goto('http://localhost:41999/');
  await page.waitForFunction(()=>document.querySelector('#lab-name').textContent==='معمل الاختبار');
  assert.equal(await page.locator('#total').textContent(),'0');assert.match(await page.locator('#empty-state').textContent(),/لا توجد أجهزة/);
  devices=[{id:'PC-01',online:true,approved:true,platform:'Windows',ip:'127.0.0.1'},{id:'PC-02',online:false,approved:true}];
  await page.evaluate(()=>refresh());
  assert.equal(await page.locator('#devices .device').count(),2);assert.equal(await page.locator('#devices img').count(),0);
  await page.click('#view-list');assert.equal(await page.locator('#view-list').getAttribute('aria-pressed'),'true');assert.equal(await page.locator('#devices.list-view').count(),1);
  await page.fill('#search','missing');assert.match(await page.locator('#empty-state').textContent(),/تطابق البحث/);await page.fill('#search','');
  await page.click('nav [data-page="screens"]');await page.waitForFunction(()=>!refreshBusy);
  assert.equal(await page.locator('#devices img').count(),1,'offline devices never show previews');
  devices[0].approved=false;await page.evaluate(()=>refresh());assert.equal(await page.locator('#devices img').count(),0,'unapproved devices never show previews');
  devices[0].approved=true;await page.evaluate(()=>refresh());
  await page.locator('#devices .has-preview').press('Enter');assert.equal(await page.locator('#screen-dialog').evaluate(x=>x.open),true);
  framesFail=true;await page.evaluate(()=>refresh());assert.equal(await page.locator('#devices img').count(),0);assert.equal(await page.locator('#screen-large').getAttribute('src'),null);assert.match(await page.locator('#notice').textContent(),/تعذر تحديث/);
  framesFail=false;frameMode='stale';await page.evaluate(()=>refresh());assert.equal(await page.locator('#devices img').count(),0,'expired frames must not render');
  await page.click('#screen-close');await page.click('nav [data-page="control"]');assert.equal(await page.locator('#devices .device').count(),0);assert.match(await page.locator('#notice').textContent(),/غير متاحة/);
  await page.click('nav [data-page="home"]');await page.waitForFunction(()=>!refreshBusy);
  statusFail=true;await page.evaluate(()=>refresh());assert.equal(await page.locator('#total').textContent(),'—');assert.equal(await page.locator('#devices .device').count(),0);assert.match(await page.locator('#mode').textContent(),/تعذر/);
  statusFail=false;await page.evaluate(()=>refresh());assert.equal(await page.locator('#total').textContent(),'2');
  await page.setViewportSize({width:390,height:844});assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true,'mobile must fit viewport');
  await page.setViewportSize({width:1280,height:900});
  devices.push({id:'PC-03',online:true,approved:false});await page.evaluate(()=>refresh());
  await page.click('nav [data-page="messages"]');await page.waitForFunction(()=>!refreshBusy);
  assert.equal(await page.locator('#message-recipients input').count(),1,'only online approved devices are selectable');
  assert.equal(await page.locator('#message-send').isDisabled(),true);
  await page.fill('#message-text','تعليمات <script>window.BAD=true</script>');await page.click('#message-select-all');
  assert.equal(await page.locator('#message-send').isEnabled(),true);await page.click('#message-send');
  await page.waitForFunction(()=>!messageSending);assert.deepEqual(sends[0].deviceIds,['PC-01']);
  assert.match(await page.locator('#message-history').textContent(),/<script>/);assert.equal(await page.evaluate(()=>window.BAD),undefined);
  assert.equal(await page.locator('#message-history script').count(),0);
  messages[0].recipients[0].state='read';await page.evaluate(()=>loadMessageHistory());assert.match(await page.locator('#message-history').textContent(),/أكد الطالب/);
  messageFail=true;await page.fill('#message-text','try again');await page.click('#message-send');await page.waitForFunction(()=>!messageSending);assert.match(await page.locator('#message-result').textContent(),/اتصال الأجهزة/);
  devices[0].approved=false;await page.evaluate(()=>refresh());assert.equal(await page.locator('#message-recipients input').count(),0);assert.equal(await page.locator('#message-send').isDisabled(),true);
  devices[0].approved=true;await page.evaluate(()=>refresh());
  await page.setViewportSize({width:390,height:844});assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);await page.setViewportSize({width:1280,height:900});
  await page.evaluate(()=>{
   window.fbsTracks=[];
   Object.defineProperty(navigator.mediaDevices,'getDisplayMedia',{configurable:true,value:async()=>{
    if(window.fbsDenyCapture)throw new DOMException('Denied','NotAllowedError');
    if(window.fbsDelayCapture)await new Promise(resolve=>window.fbsResolveCapture=resolve);
    const canvas=document.createElement('canvas');canvas.width=640;canvas.height=360;const ctx=canvas.getContext('2d');ctx.fillStyle='#1766d6';ctx.fillRect(0,0,640,360);
    const stream=canvas.captureStream(2);window.fbsTracks.push(...stream.getTracks());return stream;
   }});
  });
  await page.click('nav [data-page="broadcast"]');await page.waitForFunction(()=>!refreshBusy&&!broadcastStateBusy);
  assert.equal(await page.locator('#broadcast-recipients input').count(),1);await page.click('#broadcast-all');
  await page.click('#broadcast-start');await page.waitForFunction(()=>broadcastSequence>0&&!broadcastSending&&!broadcastBusy);
  assert.equal(startCalls,1);assert.deepEqual(broadcast.deviceIds,['PC-01']);assert.ok(captured.length>0);
  const {jpegDimensions}=require('../../classroom-broadcast');assert.deepEqual(jpegDimensions(captured[0].jpeg),{width:1280,height:720});
  assert.equal(await page.locator('#broadcast-preview').isVisible(),true);
  await page.click('#broadcast-stop');await page.waitForFunction(()=>!broadcastSession&&document.querySelector('#broadcast-state').textContent==='تم إيقاف مشاركة الشاشة');
  assert.equal(broadcast.active,false);assert.equal(await page.evaluate(()=>window.fbsTracks.every(t=>t.readyState==='ended')),true);
  await page.evaluate(()=>window.fbsDenyCapture=true);await page.click('#broadcast-start');await page.waitForFunction(()=>!broadcastBusy);assert.equal(startCalls,1);assert.match(await page.locator('#broadcast-state').textContent(),/رُفض الإذن/);
  await page.evaluate(()=>{window.fbsDenyCapture=false;window.fbsDelayCapture=true;});await page.click('#broadcast-start');await page.click('#broadcast-stop');
  await page.evaluate(()=>window.fbsResolveCapture());await page.waitForFunction(()=>window.fbsTracks.every(t=>t.readyState==='ended'));assert.equal(startCalls,1,'cancelled chooser must never create a server session');
  await page.evaluate(()=>window.fbsDelayCapture=false);await page.click('#broadcast-start');await page.waitForFunction(()=>broadcastSequence>0&&!broadcastBusy&&!broadcastSending);
  await page.click('nav [data-page="home"]');await page.waitForFunction(()=>!broadcastSession);assert.equal(await page.evaluate(()=>window.fbsTracks.every(t=>t.readyState==='ended')),true);
  await page.click('nav [data-page="broadcast"]');await page.waitForFunction(()=>!refreshBusy&&!broadcastStateBusy);await page.click('#broadcast-all');frameFail=true;
  await page.click('#broadcast-start');await page.waitForFunction(()=>!broadcastBusy&&!broadcastStream);assert.equal(await page.evaluate(()=>window.fbsTracks.every(t=>t.readyState==='ended')),true);
  assert.equal(broadcast.active,false);frameFail=false;
  await page.evaluate(()=>window.scrollTo(0,0));
  await page.click('#broadcast-start');await page.waitForFunction(()=>broadcastSequence>0&&!broadcastBusy&&!broadcastSending);await page.evaluate(()=>window.scrollTo(0,0));
  if(process.env.FBS_SCREENSHOT)await page.screenshot({path:process.env.FBS_SCREENSHOT,fullPage:true});
  await page.evaluate(()=>stopBroadcast());
  assert.deepEqual(errors,[]);console.log('M174 browser acceptance passed: canvas MediaStream capture and JPEG upload, chooser rejection/cancellation, stop/navigation/failure track cleanup; previous checks: message recipients, text-only rendering, queued/read states, send failure, revoke and mobile layout; regression: empty/search/list, live roster, consent/online/fresh previews, HTTP failure cleanup, unavailable features, recovery, mobile layout, no JS errors.');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
