using System;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using System.Windows.Forms;

namespace FBS.Student.Native;

// M17: starts the existing LAN agent in the signed-in user's interactive session.
// The agent cannot operate without a DPAPI-protected pairing key configured by the user.
internal sealed class AgentHost : IDisposable
{
    private Process? process;
    public string LocalControlToken { get; } = Convert.ToHexString(RandomNumberGenerator.GetBytes(32));
    public bool Running => process is { HasExited: false };
    public string Status { get; private set; } = "لم يتم تشغيل وكيل الشبكة";

    public void Start()
    {
        var app = AppContext.BaseDirectory;
        var runtime = Path.GetFullPath(Path.Combine(app, "..", "Runtime"));
        var node = Path.Combine(runtime, "node.exe");
        var agent = Path.Combine(runtime, "student-agent.js");
        var credential = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FBSClassroom", "pairing.dpapi");
        if (!File.Exists(node) || !File.Exists(agent)) { Status = "ملفات وكيل الشبكة غير موجودة"; return; }
        if (!File.Exists(credential)) { Status = "يجب إعداد مفتاح المعمل أولاً"; return; }
        if (Running) return;
        // Decrypt the key in PowerShell under the same Windows user, and launch Node.
        // No secret is embedded in the command line or persisted in plaintext.
        var script = Path.Combine(runtime, "Start-Student-Agent.ps1");
        if (!File.Exists(script)) { Status = "ملف تشغيل وكيل الشبكة غير موجود"; return; }
        try
        {
            var startInfo = new ProcessStartInfo("powershell.exe")
            {
                UseShellExecute = false,
                CreateNoWindow = true,
                WindowStyle = ProcessWindowStyle.Hidden,
                Arguments = $"-NoProfile -NonInteractive -File \"{script}\"",
                WorkingDirectory = runtime
            };
            startInfo.Environment["FBS_LOCAL_CONTROL_TOKEN"] = LocalControlToken;
            process = Process.Start(startInfo);
            Status = process is null ? "تعذّر تشغيل وكيل الشبكة" : "تم بدء وكيل الشبكة المحلي";
        }
        catch (Exception ex) { Status = "تعذّر تشغيل الوكيل: " + ex.Message; }
    }

    public void Dispose()
    {
        try { if (Running) process!.Kill(entireProcessTree: true); } catch { }
        process?.Dispose();
    }
}
