// Offline distribution completeness check. Does not launch or enable remote control.
'use strict';
const fs=require('node:fs');
const path=require('node:path');
const root=process.argv[2];
const required=['Teacher/FBS.Teacher.exe','Student/FBS.Student.Native.exe','Runtime/node.exe','Runtime/server.js','Runtime/student-agent.js','Runtime/teacher-lan.js','Runtime/control-commands.js','Runtime/control-lease.js','Runtime/control-session-state.js','Runtime/preview-validation.js','Runtime/device-identity.js','Runtime/enrollment.js','Runtime/lan.js','Runtime/local-control-auth.js','Runtime/Start-Student-Agent.ps1','Runtime/public/index.html'];
function verify(dir){if(!dir) return {ok:false,missing:['distribution path']};const missing=required.filter(p=>{try{return !fs.statSync(path.join(dir,p)).isFile()}catch{return true}});return {ok:missing.length===0,missing};}
if(require.main===module){const result=verify(root);console.log(JSON.stringify(result,null,2));process.exitCode=result.ok?0:1;}
module.exports={verify,required};
