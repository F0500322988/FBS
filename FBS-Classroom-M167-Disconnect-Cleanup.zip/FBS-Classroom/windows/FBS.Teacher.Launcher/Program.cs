using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

namespace FBS.Teacher.Launcher;
internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        // M150: optional local administrator audit is available from the teacher launcher.
        // It does not provision devices or bypass teacher/server authentication.
        if (MessageBox.Show("هل تريد فتح فحص إعدادات مسؤول المعمل المحلي؟\nاختر لا لتشغيل لوحة المعلم.",
            "FBS Classroom", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
        {
            Application.Run(new TeacherAdminAuditForm());
            return;
        }
        var root = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "Runtime"));
        var server = Path.Combine(root, "server.js");
        if (!File.Exists(server))
        {
            MessageBox.Show("لم يتم العثور على server.js. شغّل البرنامج من مجلد dist بجانب ملفات المشروع.", "FBS Classroom");
            return;
        }
        if (string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable("FBS_PAIRING_KEY")) ||
            string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable("FBS_TEACHER_PASSWORD")) ||
            string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable("FBS_TLS_CERT")) ||
            string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable("FBS_TLS_KEY")))
        {
            MessageBox.Show("يجب إعداد مفتاح المعمل وكلمة مرور المعلم ومسارات شهادة TLS قبل التشغيل.", "FBS Classroom");
            return;
        }
        try
        {
            using var process = Process.Start(new ProcessStartInfo(Path.Combine(root, "node.exe"), "\"" + server + "\"")
            {
                WorkingDirectory = root,
                UseShellExecute = false,
                CreateNoWindow = true
            });
            if (process == null) throw new Exception("تعذّر بدء خادم المعلم");
            System.Threading.Thread.Sleep(1300);
            if (process.HasExited) throw new Exception("توقف الخادم أثناء التشغيل. راجع إعدادات TLS.");
            Process.Start(new ProcessStartInfo("http://127.0.0.1:4177") { UseShellExecute = true });
            MessageBox.Show("لوحة المعلم تعمل في المتصفح. اضغط موافق لإيقاف الخادم عند الانتهاء.", "FBS Classroom");
            if (!process.HasExited) process.Kill(entireProcessTree: true);
        }
        catch (Exception ex)
        {
            MessageBox.Show("تعذر التشغيل: " + ex.Message + "\nتأكد من تثبيت Node.js وإعداد الاتصال.", "FBS Classroom");
        }
    }
}
