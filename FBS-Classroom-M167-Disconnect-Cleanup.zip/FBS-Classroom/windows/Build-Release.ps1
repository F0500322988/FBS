param([string]$OutputDirectory = '.\release')
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$target = [IO.Path]::GetFullPath((Join-Path $root $OutputDirectory))
$node = Get-Command node.exe -ErrorAction Stop
$dotnet = Get-Command dotnet.exe -ErrorAction Stop
New-Item -ItemType Directory -Force -Path $target | Out-Null
$runtime = Join-Path $target 'Runtime'
New-Item -ItemType Directory -Force -Path $runtime | Out-Null
$files = @('server.js','teacher-lan.js','student-agent.js','lan.js','device-identity.js','local-control-auth.js')
foreach ($file in $files) { Copy-Item (Join-Path $root $file) $runtime -Force }
Copy-Item (Join-Path $PSScriptRoot 'Start-Student-Agent.ps1') (Join-Path $runtime 'Start-Student-Agent.ps1') -Force
Copy-Item (Join-Path $root 'public') (Join-Path $runtime 'public') -Recurse -Force
# Node executable must be the Windows binary. Do not bundle a Linux executable.
Copy-Item $node.Source (Join-Path $runtime 'node.exe') -Force
$teacher = Join-Path $PSScriptRoot 'FBS.Teacher.Launcher\FBS.Teacher.Launcher.csproj'
$student = Join-Path $PSScriptRoot 'FBS.Student.Native\FBS.Student.Native.csproj'
& $dotnet.Source publish $teacher -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o (Join-Path $target 'Teacher')
if ($LASTEXITCODE -ne 0) { throw 'Teacher build failed' }
& $dotnet.Source publish $student -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o (Join-Path $target 'Student')
if ($LASTEXITCODE -ne 0) { throw 'Student build failed' }
Copy-Item (Join-Path $PSScriptRoot 'Install-Student.ps1') (Join-Path $target 'Install-Student.ps1') -Force
Copy-Item (Join-Path $PSScriptRoot 'Uninstall-Student.ps1') (Join-Path $target 'Uninstall-Student.ps1') -Force
Write-Host "Release assembled at $target"
Write-Host 'This is a developer build, NOT a complete student installer or remote-control EXE.'
