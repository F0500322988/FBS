param([string]$InnoCompiler = '')
$ErrorActionPreference = 'Stop'
$root=Split-Path -Parent $PSScriptRoot
& (Join-Path $PSScriptRoot 'Build-Release.ps1')
if ($LASTEXITCODE -ne 0) { throw 'Build-Release failed' }
if (-not $InnoCompiler) {
  $candidates=@("${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe", "${env:ProgramFiles}\Inno Setup 6\ISCC.exe")
  $InnoCompiler=$candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
}
if (-not $InnoCompiler -or -not (Test-Path $InnoCompiler)) { throw 'Install Inno Setup 6, or supply -InnoCompiler path to ISCC.exe' }
foreach($name in @('FBS-Teacher.iss','FBS-Student.iss')) {
  & $InnoCompiler (Join-Path $PSScriptRoot "installer\$name")
  if ($LASTEXITCODE -ne 0) { throw "Inno Setup compilation failed: $name" }
}
Write-Host "Preview installers created in $(Join-Path $root 'release\installers')"
