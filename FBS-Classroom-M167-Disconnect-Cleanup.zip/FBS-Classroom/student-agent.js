'use strict';
const dgram=require('node:dgram'),http=require('node:http'),https=require('node:https'),crypto=require('node:crypto'),os=require('node:os');
const {localIPv4,signature,safeEqual}=require('./lan');
const {getIdentity,signMessage}=require('./device-identity');
const identity=getIdentity();
const {authorizedLocalRequest}=require('./local-control-auth');
const {createStudentPreviewTransport}=require('./authenticated-preview-transport');
const {initialState,applyPoll,localClose,confirmStop}=require('./control-session-state');
const localControlToken=process.env.FBS_LOCAL_CONTROL_TOKEN||'';
const secret=process.env.FBS_PAIRING_KEY;
if(!secret||secret.length<16){console.error('FBS_PAIRING_KEY must match the teacher key (at least 16 characters).');process.exit(1);}
const id=(process.env.FBS_DEVICE_ID||os.hostname()).replace(/[^\w.-]/g,'_').slice(0,64);
const port=Number(process.env.FBS_DISCOVERY_PORT||4181);
const udp=dgram.createSocket('udp4');let teacher=null;
let sharing=false;
const capturePage=`<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><title>FBS Student — مشاركة الشاشة</title><style>body{font:18px system-ui;background:#f3f7ff;color:#152b4e;max-width:650px;margin:60px auto}button{padding:12px 22px;margin:8px;border:0;border-radius:8px;background:#1658ac;color:white;cursor:pointer}#stop{background:#a42a39}</style><h2>FBS Classroom — مشاركة شاشة الطالب</h2><p>المشاركة اختيارية في هذا الإصدار التجريبي. ستظهر نافذة من المتصفح لتحديد الشاشة، ويمكنك الإيقاف في أي وقت. تنبيه: النقل داخل الشبكة غير مشفر بعد، فلا تشارك محتوى حساسًا.</p><button id="start">بدء مشاركة الشاشة</button><button id="stop">إيقاف المشاركة</button><p id="state">غير مشارك</p><video id="preview" autoplay muted playsinline width="480"></video><script>let stream,timer;const state=document.getElementById('state');async function stop(){clearInterval(timer);if(stream)stream.getTracks().forEach(t=>t.stop());stream=null;state.textContent='تم إيقاف المشاركة'}document.getElementById('stop').onclick=stop;document.getElementById('start').onclick=async()=>{try{await stop();stream=await navigator.mediaDevices.getDisplayMedia({video:{frameRate:1},audio:false});document.getElementById('preview').srcObject=stream;stream.getVideoTracks()[0].onended=stop;state.textContent='الشاشة قيد المشاركة';const canvas=document.createElement('canvas');canvas.width=640;canvas.height=360;timer=setInterval(async()=>{if(!stream||!document.getElementById('preview').videoWidth)return;canvas.getContext('2d').drawImage(document.getElementById('preview'),0,0,640,360);try{await fetch('/frame',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({jpeg:canvas.toDataURL('image/jpeg',.45)})})}catch{}},1500)}catch(e){state.textContent='لم تبدأ المشاركة: '+e.message}};</script></html>`;
let pendingControl=null;
let previewCommands=[];
let stopReceipt=null;
let controlState=initialState();
let locallyStoppedSession=null;
const previewTransport=createStudentPreviewTransport({secret,deviceId:id});
function signedControl(path,body,onResponse){
 if(!teacher)return;
 const data=JSON.stringify(signMessage(identity,{id,platform:process.platform,...body}));
 const req=https.request({rejectUnauthorized:false,checkServerIdentity:()=>undefined,host:teacher.host,port:teacher.port,path,method:'POST',timeout:2500,headers:{'Content-Type':'application/json','Content-Length':Buffer.byteLength(data),'X-FBS-Key':secret}},res=>{
  let raw='';res.on('data',c=>{if(raw.length<8192)raw+=c});res.on('end',()=>{if(res.statusCode===200||res.statusCode===204)try{onResponse?.(raw?JSON.parse(raw):{});}catch{}});
 });req.on('socket',pinSocket);req.on('error',()=>{});req.on('timeout',()=>req.destroy());req.end(data);
}
function pollPreviewCommands(){signedControl('/control/commands',{},result=>{
 const items=Array.isArray(result.commands)?result.commands:[];
 for(const envelope of items){
 const cmd=previewTransport.accept(envelope,{session:pendingControl,connected:!!teacher,enrolled:true,indicatorVisible:pendingControl?.status==='consented-no-input',studentStopped:pendingControl?.sessionId===locallyStoppedSession});
 if(cmd && cmd.sessionId!==locallyStoppedSession){
  previewCommands.push({sessionId:cmd.sessionId,type:cmd.type,sequence:cmd.sequence,at:Date.now(),x:cmd.x,y:cmd.y,key:cmd.key,description:cmd.type==='pointer-preview'?`Pointer preview (${cmd.x}, ${cmd.y})`:`Key preview (${cmd.key})`});
  if(previewCommands.length>20)previewCommands.shift();
  console.log('[FBS M121 AUTHENTICATED PREVIEW ONLY] command received:',cmd.type,cmd.sequence);
 }
 }
 });}
function pollControl(){
 const requestRevision=controlState.revision;
 signedControl('/control/poll',{},result=>{
  controlState=applyPoll(controlState,result.session,requestRevision);
  pendingControl=controlState.session;
  previewCommands=controlState.previewCommands;
  if(!pendingControl||pendingControl.status!=='consented-no-input')previewTransport.revoke();
 });
}
function localControl(req,res){
 const send=(status,body)=>{res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(body));};
 if(!authorizedLocalRequest(req,localControlToken))return send(403,{error:'Unauthorized local controller'});
 if(req.method==='GET')return send(200,{session:pendingControl,inputEnabled:false,stopReceipt,previewCommands:pendingControl?.status==='consented-no-input'?previewCommands:[]});
 if(req.method!=='POST')return send(405,{error:'Method not allowed'});
 let raw='';req.on('data',c=>{raw+=c;if(raw.length>1024)req.destroy()});req.on('end',()=>{
  try{
   const body=JSON.parse(raw);
   if(!pendingControl||body.sessionId!==pendingControl.sessionId)return send(409,{error:'No matching session'});
   if(body.stop===true){
    previewTransport.revoke();
    const sessionId=pendingControl.sessionId;
    controlState=localClose(controlState,sessionId,'stop');
    pendingControl=controlState.session;previewCommands=controlState.previewCommands;
    locallyStoppedSession=sessionId;
    stopReceipt=controlState.stopReceipt;
    signedControl('/control/stop',{sessionId},()=>{
      controlState=confirmStop(controlState,sessionId);
      stopReceipt=controlState.stopReceipt;
    });
    return send(202,{submitted:true,confirmed:false,inputEnabled:false});
   }
   if(pendingControl.status!=='pending-native-consent'||typeof body.approved!=='boolean')return send(409,{error:'Not awaiting consent'});
   const sessionId=pendingControl.sessionId;
   if(!body.approved){controlState=localClose(controlState,sessionId,'denied');pendingControl=controlState.session;previewCommands=controlState.previewCommands;}
   signedControl('/control/ack',{sessionId,approved:body.approved});
   send(202,{submitted:true,inputEnabled:false});
  }catch{send(400,{error:'Invalid request'});}
 });
}
const localServer=http.createServer((req,res)=>{
 if(req.url==='/control/local')return localControl(req,res);
if(req.method==='GET'&&req.url==='/'){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});return res.end(capturePage)}if(req.method==='POST'&&req.url==='/frame'){let chunks=[],size=0;req.on('data',c=>{size+=c.length;if(size>175000){req.destroy();return;}chunks.push(c)});return req.on('end',()=>{try{const body=JSON.parse(Buffer.concat(chunks).toString());if(!teacher||typeof body.jpeg!=='string'||body.jpeg.length>170000)throw Error('no teacher');const data=JSON.stringify(signMessage(identity,{id,platform:process.platform,jpeg:body.jpeg}));const r=https.request({rejectUnauthorized:false,checkServerIdentity:()=>undefined,host:teacher.host,port:teacher.port,path:'/frame',method:'POST',timeout:2500,headers:{'Content-Type':'application/json','Content-Length':Buffer.byteLength(data),'X-FBS-Key':secret}},x=>x.resume());r.on('socket',pinSocket);r.on('error',()=>{});r.on('timeout',()=>r.destroy());r.end(data);res.writeHead(202);res.end()}catch{res.writeHead(400);res.end()}})}res.writeHead(404);res.end()});
localServer.listen(4190,'127.0.0.1',()=>console.log('Optional screen share: http://127.0.0.1:4190')); 
function pinSocket(socket){
 socket.once('secureConnect',()=>{
  const cert=socket.getPeerCertificate(true);
  const actual=cert?.raw?crypto.createHash('sha256').update(cert.raw).digest('hex'):'';
  if(!teacher||actual!==teacher.fingerprint)socket.destroy(new Error('Teacher TLS certificate mismatch'));
 });
}
function heartbeat(){if(!teacher)return;const data=JSON.stringify(signMessage(identity,{id,platform:process.platform,addresses:localIPv4()}));const req=https.request({rejectUnauthorized:false,checkServerIdentity:()=>undefined,host:teacher.host,port:teacher.port,path:'/heartbeat',method:'POST',timeout:3000,headers:{'Content-Type':'application/json','Content-Length':Buffer.byteLength(data),'X-FBS-Key':secret}},res=>res.resume());req.on('socket',pinSocket);req.on('error',()=>{});req.on('timeout',()=>req.destroy());req.end(data);}
udp.on('message',(buf,remote)=>{try{const msg=JSON.parse(buf.toString());if(!safeEqual(signature(secret,msg.payload),msg.mac))return;const p=JSON.parse(msg.payload);if(p.type!=='fbs-teacher-v1'||Math.abs(Date.now()-p.timestamp)>10000||!Number.isInteger(p.port)||p.port<1||p.port>65535)return;if(!/^[a-f0-9]{64}$/.test(p.fingerprint))return;teacher={host:remote.address,port:p.port,fingerprint:p.fingerprint};heartbeat();}catch{}});
udp.bind(port,'0.0.0.0',()=>console.log('Student agent',id,'IP:',localIPv4().join(', '),'waiting for teacher discovery on UDP',port));
setInterval(heartbeat,5000);
setInterval(pollControl,2000);

setInterval(pollPreviewCommands,2000);
